Files with "html" extension in this directory and its subdirectories are freemarker templates for AjaxSwing custom components.

Standard Edition only allows 2 custom renderers, so be sure to remove (or rename to .bak extension) the existing templates before adding yours.

For details see http://www.creamtec.com/products/ajaxswing/doc/CustomComponents.html
