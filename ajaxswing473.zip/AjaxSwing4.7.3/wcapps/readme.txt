Applications working directory.

This is the current directory for applications that are running in AjaxSwing web server
