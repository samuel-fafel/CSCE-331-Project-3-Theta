This directory will be added to AjaxSwing's CLASSPATH. Place all .class files here.

